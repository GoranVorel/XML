<?php
$username="";
$password="";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	$ans=$_POST;

	if (empty($ans["username"]))  {
        echo "<script type='text/javascript'>alert('Username is missing!');</script>";
		
    		}
	else if (empty($ans["password"]))  {
        echo "<script type='text/javascript'>alert('Password is missing!');</script>";
		
    		}
	else {
		$username= $ans["username"];
		$password= $ans["password"];
	
		validation($username,$password);
	}
}

function validation($username, $password) {
	
	$xml=simplexml_load_file("users.xml");
	
	foreach ($xml->user as $usr) {
  	 	$usrn = $usr->username;
		$usrp = $usr->password;
		if($usrn==$username){
			if($usrp == $password){
				echo "<script type='text/javascript'>alert('Welcome $usrn!');</script>";
				return;
				}
			else{
				echo "<script type='text/javascript'>alert('Wrong password');</script>";
				return;
				}
			}
		}
		
	echo "<script type='text/javascript'>alert('User does not exist');</script>";;
	return;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>

    <style>
        .main{
            display: flex;
            justify-content: center;
            color: greenyellow;
            background-color: black;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            padding: 10%;
        }
        .d1,.d2{
            position: relative;
        }

    </style>

</head>
<body>

    <div class="d1"></div>

    <section class="main">

    <form action="" method="post">
        <div>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username">
        </div>
        <div>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password">
        </div>
        <input name="submit" type="submit" value=" Login ">
    </form>

    </section>

    <div class="d2"></div>

</body>
</html>
